# HTML-Template
An HTML template to start coding right away
